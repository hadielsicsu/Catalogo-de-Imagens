import ImageDAO from "../persistencia/imageDAO.mjs";

export default class ImageModal {
    constructor(id, title, description, imageUrl, author, createdAt, category) {
      this.id = id;
      this.title = title;
      this.description = description;
      this.imageUrl = imageUrl;
      this.author = author;
      this.createdAt = createdAt;
      this.category = category;
    }
  }
  