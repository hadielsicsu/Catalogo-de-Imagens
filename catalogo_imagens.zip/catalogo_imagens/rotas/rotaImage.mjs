/**
 * @swagger
 * /images:
 *   get:
 *     summary: Obter todas as imagens
 *     tags: [Images]
 *     responses:
 *       200:
 *         description: Lista de todas as imagens
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Image'
 *       404:
 *         description: Nenhuma imagem encontrada
 */

/**
 * @swagger
 * /images/{id}:
 *   put:
 *     summary: Atualizar uma imagem existente
 *     tags: [Images]
 *     parameters:
 *       - in: path
 *         name: id
 *         description: ID da imagem a ser atualizada
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Image'
 *     responses:
 *       200:
 *         description: Imagem atualizada com sucesso
 *       404:
 *         description: Imagem não encontrada
 *
 *   delete:
 *     summary: Excluir uma imagem existente
 *     tags: [Images]
 *     parameters:
 *       - in: path
 *         name: id
 *         description: ID da imagem a ser excluída
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Imagem excluída com sucesso
 *       404:
 *         description: Imagem não encontrada
 */


import express from 'express';
const router = express.Router();
import ImageController from '../controle/imageController.mjs';

router.post('/', ImageController.cadastrarImagem);
router.get('/', ImageController.listaImagens);
router.put('/:id', ImageController.atualizarImagem);
router.delete('/:id', ImageController.excluirImagem);

export default router; 