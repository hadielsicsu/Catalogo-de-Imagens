// Importe os pacotes necessários
import swaggerJsdoc from 'swagger-jsdoc';

// Defina as opções de configuração para o Swagger
const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Catalogo de Imagens API',
      version: '1.0.0',
      description: 'API para manipulação de imagens',
    },
    // Defina os componentes e esquemas aqui
    components: {
      schemas: {
        Image: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            title: { type: 'string' },
            description: { type: 'string' },
            imageUrl: { type: 'string' },
            author: { type: 'string' },
            createdAt: { type: 'string' }, 
            category: { type: 'string' },
          },
        },
      },
    },
  },
  // Especifique os arquivos que contêm as rotas da API
  apis: ['./rotas/*.mjs'],
};

// Crie as specs do Swagger
const specs = swaggerJsdoc(options);

// Exporte as specs
export default specs;
