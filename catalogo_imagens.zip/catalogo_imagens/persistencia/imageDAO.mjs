import fs from 'fs';

export default class ImageDAO {
  constructor(databasePath) {
    this.databasePath = databasePath;
  }

  // Método para carregar todas as imagens do banco de dados
  loadImagesFromDatabase() {
    const rawData = fs.readFileSync(this.databasePath);
    return JSON.parse(rawData.toString());
  }

  // Método para buscar uma imagem pelo ID
  findImageById(id) {
    const images = this.loadImagesFromDatabase();
    return images.find(image => image.id === id);
  }

  // Método para adicionar uma nova imagem ao banco de dados
  addImage(image) {
    const images = this.loadImagesFromDatabase();
    images.push(image);
    fs.writeFileSync(this.databasePath, JSON.stringify(images));
  }

  // Método para atualizar uma imagem existente no banco de dados
  updateImage(image) {
    const images = this.loadImagesFromDatabase();
    const index = images.findIndex(img => img.id === image.id);
    if (index !== -1) {
      images[index] = image;
      fs.writeFileSync(this.databasePath, JSON.stringify(images));
      return true;
    }
    return false; // Retornar falso se a imagem não for encontrada
  }

  // Método para excluir uma imagem do banco de dados
  deleteImage(id) {
    const images = this.loadImagesFromDatabase();
    const filteredImages = images.filter(image => image.id !== id);
    fs.writeFileSync(this.databasePath, JSON.stringify(filteredImages));
  }
}
